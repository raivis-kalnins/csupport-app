/** ClientWatch Node.js helper (Node 20+). Server-side only; no dependencies. */
import {createHmac,randomBytes} from 'node:crypto';
const scrub=value=>String(value||'').slice(0,1000).replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,'[email]').replace(/\b(password|passwd|token|api[_-]?key|secret|authorization|cookie)\s*[:=]\s*[^\s,;]+/gi,'$1=[redacted]').replace(/(https?:\/\/[^\s?#]+)[?#][^\s]*/gi,'$1');
export function createClientWatch(options={}) {
  const url=options.url||process.env.CLIENTWATCH_URL;
  const site=options.site||process.env.CLIENTWATCH_SITE_ID;
  const secret=options.secret||process.env.CLIENTWATCH_SECRET;
  const allowHttp=options.allowHttp===true||process.env.CLIENTWATCH_ALLOW_HTTP==='1';
  const parsed=new URL(url);
  if((parsed.protocol!=='https:'&&!(allowHttp&&parsed.protocol==='http:'))||parsed.username||parsed.password||parsed.search||parsed.hash||!parsed.pathname.endsWith('/index.php'))throw new Error('Configure a full HTTPS ClientWatch URL ending in /index.php.');
  if(!/^[a-f0-9]{16}$/.test(site||'')||!/^[a-f0-9]{64}$/.test(secret||''))throw new Error('Configure the server-side ClientWatch Site ID and private secret.');
  async function send(payload){
    const body=JSON.stringify(payload),timestamp=String(Math.floor(Date.now()/1000)),nonce=randomBytes(16).toString('hex');
    const signature=createHmac('sha256',secret).update(`${timestamp}\n${nonce}\n${body}`).digest('hex');
    const response=await fetch(url+'?api=report',{method:'POST',redirect:'error',headers:{'Content-Type':'application/json','X-CW-Site':site,'X-CW-Timestamp':timestamp,'X-CW-Nonce':nonce,'X-CW-Signature':signature},body,signal:AbortSignal.timeout(3000)});
    const result=await response.json();if(!response.ok||!result.ok)throw new Error('ClientWatch report rejected: HTTP '+response.status);
    return result;
  }
  function heartbeat(){return send({report:{kind:'node',runtime:'Node.js '+process.versions.node,connector:'1.0.0'}});}
  function error(err,context={}){
    return send({errors:[{id:randomBytes(12).toString('hex'),message:scrub(err instanceof Error?err.message:err),severity:context.severity||'error',file:String(context.file||'').split(/[\\/]/).pop(),line:Number(context.line)||0,path:new URL(context.path||'/', 'https://path.invalid').pathname}]});
  }
  function startHeartbeat(intervalMs=300000){
    const run=()=>heartbeat().catch(()=>{});run();const timer=setInterval(run,Math.max(60000,intervalMs));timer.unref();return ()=>clearInterval(timer);
  }
  return Object.freeze({send,heartbeat,error,startHeartbeat});
}
