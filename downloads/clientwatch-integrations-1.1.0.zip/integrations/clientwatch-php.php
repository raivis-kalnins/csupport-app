<?php
declare(strict_types=1);
/**
 * ClientWatch PHP integration. Configure CLIENTWATCH_URL, CLIENTWATCH_SITE_ID,
 * CLIENTWATCH_SECRET as SERVER-SIDE environment variables. No Composer needed.
 * Include early, then call ClientWatchReporter::registerFatalHandler().
 * For a periodic runtime report: php clientwatch-php.php --heartbeat
 */
final class ClientWatchReporter {
    private static string $reserve='';
    private static bool $registered=false;
    private static function config(): array {
        $url=rtrim((string)getenv('CLIENTWATCH_URL'),'/');$id=(string)getenv('CLIENTWATCH_SITE_ID');$secret=(string)getenv('CLIENTWATCH_SECRET');
        if (!filter_var($url,FILTER_VALIDATE_URL)||!str_ends_with((string)parse_url($url,PHP_URL_PATH),'/index.php')||parse_url($url,PHP_URL_QUERY)||parse_url($url,PHP_URL_FRAGMENT)||parse_url($url,PHP_URL_USER)) throw new RuntimeException('Set a valid CLIENTWATCH_URL ending with /index.php.');
        if (!str_starts_with($url,'https://')&&!(getenv('CLIENTWATCH_ALLOW_HTTP')==='1'&&str_starts_with($url,'http://'))) throw new RuntimeException('Use HTTPS. CLIENTWATCH_ALLOW_HTTP=1 is for local development only.');
        if (!preg_match('/^[a-f0-9]{16}$/',$id)||!preg_match('/^[a-f0-9]{64}$/',$secret)) throw new RuntimeException('Set CLIENTWATCH_SITE_ID and CLIENTWATCH_SECRET on the server.');
        return [$url,$id,$secret];
    }
    private static function redact(string $s): string {
        $s=substr($s,0,1000);$s=preg_replace('/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i','[email]',$s) ?? '';
        $s=preg_replace('/\b(password|passwd|token|api[_-]?key|secret|authorization|cookie)\s*[:=]\s*[^\s,;]+/i','$1=[redacted]',$s) ?? '';
        return preg_replace('~(https?://[^\s?#]+)[?#][^\s]*~i','$1',$s) ?? '';
    }
    public static function send(array $payload): bool {
        try {
            [$url,$id,$secret]=self::config();$body=json_encode($payload,JSON_THROW_ON_ERROR|JSON_INVALID_UTF8_SUBSTITUTE);
            $time=(string)time();$nonce=bin2hex(random_bytes(16));$signature=hash_hmac('sha256',$time."\n".$nonce."\n".$body,$secret);
            $headers=['Content-Type: application/json','X-CW-Site: '.$id,'X-CW-Timestamp: '.$time,'X-CW-Nonce: '.$nonce,'X-CW-Signature: '.$signature];
            if (function_exists('curl_init')) {
                $ch=curl_init($url.'?api=report');curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_PROXY=>'',CURLOPT_CONNECTTIMEOUT=>2,CURLOPT_TIMEOUT=>3,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
                $response=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
            } else {
                $context=stream_context_create(['http'=>['method'=>'POST','header'=>implode("\r\n",$headers),'content'=>$body,'timeout'=>3,'ignore_errors'=>true,'follow_location'=>0],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
                $response=@file_get_contents($url.'?api=report',false,$context);$code=0;
                foreach($http_response_header ?? [] as $line)if(preg_match('~^HTTP/\S+\s+(\d{3})~',$line,$m))$code=(int)$m[1];
            }
            return $code===200&&is_string($response)&&!empty(json_decode($response,true)['ok']);
        } catch(Throwable $e) { error_log('ClientWatch reporter could not deliver a report. Check its server-side configuration and network.');return false; }
    }
    public static function heartbeat(): bool {
        $ext=[];foreach(['curl','openssl','mbstring','intl','imagick','gd','zip','mysqli','pdo','opcache'] as $name)$ext[$name]=extension_loaded($name);
        $free=@disk_free_space(__DIR__);$total=@disk_total_space(__DIR__);
        return self::send(['report'=>['kind'=>'php','connector'=>'1.1.0','runtime'=>'PHP '.PHP_VERSION,'environment'=>['platform'=>PHP_OS_FAMILY,'architecture'=>PHP_INT_SIZE===8?'64-bit':'32-bit','sapi'=>PHP_SAPI,'server'=>(string)($_SERVER['SERVER_SOFTWARE'] ?? ''),'memory_limit'=>(string)ini_get('memory_limit'),'upload_max'=>(string)ini_get('upload_max_filesize'),'post_max'=>(string)ini_get('post_max_size'),'max_execution_time'=>(string)ini_get('max_execution_time'),'disk_free_mb'=>is_numeric($free)?(int)round($free/1048576):0,'disk_total_mb'=>is_numeric($total)?(int)round($total/1048576):0,'process_memory_mb'=>(int)round(memory_get_usage(true)/1048576),'extensions'=>$ext]]]);
    }
    public static function error(Throwable|string $error,string $severity='error'): bool {
        return self::send(['errors'=>[['id'=>bin2hex(random_bytes(12)),'message'=>self::redact($error instanceof Throwable?$error->getMessage():$error),'severity'=>$severity,'file'=>$error instanceof Throwable?basename($error->getFile()):'','line'=>$error instanceof Throwable?$error->getLine():0,'path'=>(string)(parse_url($_SERVER['REQUEST_URI'] ?? '/',PHP_URL_PATH) ?: '/')]]]);
    }
    public static function registerFatalHandler(): void {
        if(self::$registered)return;self::$registered=true;self::$reserve=str_repeat('x',65536);
        register_shutdown_function(static function(): void {
            self::$reserve='';$e=error_get_last();if(!$e||!in_array($e['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR,E_RECOVERABLE_ERROR],true))return;
            self::send(['errors'=>[['id'=>bin2hex(random_bytes(12)),'message'=>self::redact($e['message']),'severity'=>'critical','file'=>basename($e['file']),'line'=>(int)$e['line'],'path'=>(string)(parse_url($_SERVER['REQUEST_URI'] ?? '/',PHP_URL_PATH) ?: '/')]]]);
        });
    }
}
if(PHP_SAPI==='cli'&&realpath($_SERVER['SCRIPT_FILENAME'] ?? '')===__FILE__){
    if(($argv[1] ?? '')!=='--heartbeat'){fwrite(STDERR,"Usage: php clientwatch-php.php --heartbeat\n");exit(2);}
    $ok=ClientWatchReporter::heartbeat();echo $ok?"Report accepted.\n":"Report failed.\n";exit($ok?0:1);
}
