# PHP and Node.js backend integrations

The public browser snippet provides frontend statistics and browser errors only.
These optional helpers provide signed server error/runtime reports. Never bundle
this private secret into frontend JavaScript, NEXT_PUBLIC_* or VITE_* variables.

Set these **server-side** environment variables:

```text
CLIENTWATCH_URL=https://YOUR-DASHBOARD/index.php
CLIENTWATCH_SITE_ID=YOUR_16_CHARACTER_SITE_ID
CLIENTWATCH_SECRET=YOUR_64_CHARACTER_PRIVATE_BACKEND_SECRET
```

Get the exact values from the website's **Connect website** tab. Use HTTPS in
production. Local development alone can use `CLIENTWATCH_ALLOW_HTTP=1`.

## Plain PHP

Keep `clientwatch-php.php` outside the public document root if practical. Include
it early in your application's bootstrap:

```php
require '/home/YOUR_ACCOUNT/private/clientwatch-php.php';
ClientWatchReporter::registerFatalHandler();
```

To report caught exceptions without replacing your existing handler:

```php
try {
    // Your application code.
} catch (Throwable $exception) {
    ClientWatchReporter::error($exception);
    throw $exception; // Preserve your application's normal behaviour.
}
```

Add a hosting cron every five minutes to show a backend heartbeat:

```cron
*/5 * * * * php /home/YOUR_ACCOUNT/private/clientwatch-php.php --heartbeat
```

Make sure cron receives the same environment variables as the website; cPanel's
web environment may not automatically apply to cron. A private PHP wrapper that
sets these variables and calls `ClientWatchReporter::heartbeat()` is another
option. Never put the secret in a publicly served file or a URL.

The helper uses cURL when available, otherwise HTTPS PHP streams. It preserves
TLS verification and does not follow redirects. Delivery is best-effort with a
three-second timeout; this generic helper has no durable retry queue.
Fatal handlers cannot see failures before this file loads and may not run on
hard process termination, an unavailable runtime or a network outage.

## Node.js / server-rendered JavaScript

Use Node.js 20+ in your **server process**:

```js
import {createClientWatch} from './clientwatch-node.mjs';
const monitor = createClientWatch();
const stopHeartbeat = monitor.startHeartbeat();

// Example: existing Express error middleware.
app.use((error, request, response, next) => {
  monitor.error(error, {path: request.path}).catch(() => {});
  next(error);
});
```

The helper does not override exception handlers or suppress crashes. Keep your
process manager's crash logs. Asynchronous network reporting during a fatal
process exit is not guaranteed. For serverless deployments send reports in your
platform's supported request-lifecycle/background mechanism, or explicitly await
the report where appropriate; do not rely on the persistent heartbeat timer.

Browser-only/static sites need only the frontend snippet. No backend helper can
be installed into an ordinary static HTML page.

## Privacy

These helpers send an error's message, filename, line and URL path, not a full
stack trace or request body. Query strings are stripped and common secret/email
patterns are redacted. Pattern-based redaction is not a guarantee: application
error messages can still contain personal or confidential data. Review your
messages and access/retention requirements before enabling reporting.
