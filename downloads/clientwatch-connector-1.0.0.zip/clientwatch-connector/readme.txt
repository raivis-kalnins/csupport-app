=== ClientWatch Connector ===
Contributors: clientwatch
Requires at least: 6.3
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPL-2.0-or-later

Read-only connector for your self-hosted ClientWatch dashboard.

== Installation ==
1. Upload this ZIP using Plugins > Add New > Upload Plugin; activate it.
2. Add this website to ClientWatch and open its Connect website tab.
3. In WordPress Settings > ClientWatch copy the dashboard URL, Site ID, public tracking key and private backend secret.
4. Save settings. Send a report and allow WP-Cron to run the fresh checks.
5. Connect your consent manager as explained on the settings screen.

== Important ==
No automatic remote updates, passwords or WordPress accounts are transferred.
The plugin inventories installed plugin/theme names and versions, core version, PHP version and selected runtime flags. It queues PHP fatal messages and sends them on a later successful report.
The tracker is inactive until analytics consent is granted. It skips logged-in visitors by default and honours Do Not Track and Global Privacy Control.
It uses random browser IDs in first-party localStorage after consent. The dashboard stores per-site HMAC hashes, not the raw browser ID. No raw IP addresses are stored by the application, but hosting access logs may store them.
Reports are scheduled every five minutes but WP-Cron is traffic-dependent. A proper hosting cron is recommended for reliable reporting.
Fatal errors before plugin bootstrap, web-server failures and errors when the WordPress database is unavailable cannot be captured by this connector. Use external HTTP monitoring and host logs as well.
Single-site setup is straightforward. On multisite configure each intended site separately; network activation does not automatically provision entries for all sites.
WP Rocket or other optimizers may need clientwatch-tracker/tracker.js excluded from delay until interaction. Avoid installing duplicate tracking snippets. Allow the dashboard origin in CSP connect-src.
