<?php
/**
 * Plugin Name: ClientWatch Connector
 * Description: Read-only WordPress update reports, queued PHP fatal alerts and consent-gated frontend analytics for your self-hosted ClientWatch dashboard.
 * Version: 1.0.0
 * Requires at least: 6.3
 * Requires PHP: 8.1
 * Author: ClientWatch
 * License: GPL-2.0-or-later
 * Text Domain: clientwatch-connector
 */
if (!defined('ABSPATH')) exit;

final class ClientWatch_Connector {
    const VERSION='1.0.0';
    const OPTION='clientwatch_connector';
    const EVENT='clientwatch_send_report';
    const FORCE='clientwatch_fresh_report';
    private static bool $sending=false;
    public static function init(): void {
        add_filter('cron_schedules',[self::class,'schedules']);
        add_action(self::EVENT,[self::class,'scheduled']);
        add_action(self::FORCE,[self::class,'fresh']);
        add_action('admin_menu',[self::class,'menu']);
        add_action('admin_post_clientwatch_save',[self::class,'save']);
        add_action('admin_post_clientwatch_send',[self::class,'manual']);
        add_action('wp_enqueue_scripts',[self::class,'enqueue']);
        add_filter('script_loader_tag',[self::class,'script_tag'],10,2);
        add_action('upgrader_process_complete',[self::class,'after_upgrade'],10,2);
        add_action('init',[self::class,'ensure_schedule']);
        register_shutdown_function([self::class,'shutdown']);
    }
    public static function config(): array { $c=get_option(self::OPTION,[]);return is_array($c)?$c:[]; }
    private static function ready(): bool { $c=self::config();return !empty($c['url'])&&!empty($c['site'])&&!empty($c['secret']); }
    private static function local(): bool { return (defined('CLIENTWATCH_ALLOW_HTTP')&&CLIENTWATCH_ALLOW_HTTP)||(function_exists('wp_get_environment_type')&&wp_get_environment_type()==='local'); }
    public static function schedules(array $s): array { $s['clientwatch_5min']=['interval'=>300,'display'=>'Every five minutes (ClientWatch)'];return $s; }
    public static function activate(): void { if (!wp_next_scheduled(self::EVENT)) wp_schedule_event(time()+60,'clientwatch_5min',self::EVENT); }
    public static function deactivate(): void { wp_clear_scheduled_hook(self::EVENT);wp_clear_scheduled_hook(self::FORCE);delete_transient('cw_report_lock'); }
    public static function ensure_schedule(): void { if(self::ready()&&!wp_next_scheduled(self::EVENT))self::activate(); }
    public static function menu(): void { add_options_page('ClientWatch','ClientWatch','manage_options','clientwatch',[self::class,'page']); }
    private static function capability(): void { if(!current_user_can('manage_options'))wp_die('You do not have permission to manage this connector.'); }
    private static function go(string $message): never { set_transient('cw_admin_notice',sanitize_text_field($message),120);wp_safe_redirect(admin_url('options-general.php?page=clientwatch'));exit; }
    public static function save(): void {
        self::capability();check_admin_referer('clientwatch_save');$old=self::config();
        $url=untrailingslashit(esc_url_raw(wp_unslash($_POST['url'] ?? '')));
        $parts=wp_parse_url($url);
        if(!$parts||empty($parts['host'])||isset($parts['user'])||isset($parts['pass'])||isset($parts['query'])||isset($parts['fragment'])||!str_ends_with($parts['path'] ?? '','/index.php'))self::go('Use a full dashboard URL ending in /index.php, without a query string.');
        if(($parts['scheme'] ?? '')!=='https'&&!self::local())self::go('HTTPS is required. HTTP is only allowed in an explicitly local development environment.');
        if(!in_array($parts['scheme'] ?? '',['https','http'],true))self::go('Invalid dashboard URL scheme.');
        $site=sanitize_text_field(wp_unslash($_POST['site'] ?? ''));$public=sanitize_text_field(wp_unslash($_POST['public_key'] ?? ''));
        $secret=sanitize_text_field(wp_unslash($_POST['secret'] ?? ''));if($secret==='')$secret=$old['secret'] ?? '';
        if(!preg_match('/^[a-f0-9]{16}$/',$site)||!preg_match('/^[a-f0-9]{32}$/',$public)||!preg_match('/^[a-f0-9]{64}$/',$secret))self::go('Check the Site ID, public tracking key and private backend secret copied from your dashboard.');
        update_option(self::OPTION,['url'=>$url,'site'=>$site,'public_key'=>$public,'secret'=>$secret,'track'=>!empty($_POST['track']),'track_logged_in'=>!empty($_POST['track_logged_in'])],false);
        self::ensure_schedule();if(!wp_next_scheduled(self::FORCE))wp_schedule_single_event(time()+5,self::FORCE);
        self::go('Settings saved. A first fresh report is queued for WP-Cron. You can also use Send report & refresh checks below.');
    }
    public static function page(): void {
        self::capability();$c=self::config();$notice=get_transient('cw_admin_notice');if($notice)delete_transient('cw_admin_notice');$last=get_option('cw_last_status',[]);
        ?>
        <div class="wrap"><h1>ClientWatch Connector</h1><p>Connect this website to your own ClientWatch dashboard. This connector reports information; it never installs updates remotely.</p>
        <?php if($notice): ?><div class="notice notice-info is-dismissible"><p><?php echo esc_html($notice); ?></p></div><?php endif; ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="clientwatch_save"><?php wp_nonce_field('clientwatch_save'); ?>
        <table class="form-table" role="presentation">
        <tr><th scope="row"><label for="cw-url">Dashboard URL</label></th><td><input class="regular-text" id="cw-url" name="url" type="url" required placeholder="https://monitor.example.com/index.php" value="<?php echo esc_attr($c['url'] ?? ''); ?>"><p class="description">Full HTTPS URL including /index.php.</p></td></tr>
        <tr><th scope="row"><label for="cw-site">Site ID</label></th><td><input class="regular-text" id="cw-site" name="site" required value="<?php echo esc_attr($c['site'] ?? ''); ?>" pattern="[a-f0-9]{16}"></td></tr>
        <tr><th scope="row"><label for="cw-public">Public tracking key</label></th><td><input class="regular-text" id="cw-public" name="public_key" required value="<?php echo esc_attr($c['public_key'] ?? ''); ?>" pattern="[a-f0-9]{32}"></td></tr>
        <tr><th scope="row"><label for="cw-secret">Private backend secret</label></th><td><input class="regular-text" id="cw-secret" name="secret" type="password" autocomplete="new-password" value="" <?php echo empty($c['secret'])?'required':''; ?>><p class="description"><?php echo empty($c['secret'])?'Paste the private secret from ClientWatch.':'Saved. Leave blank to keep the current secret; paste a new one after rotation.'; ?> Never place this secret in public JavaScript.</p></td></tr>
        <tr><th scope="row">Frontend analytics</th><td><label><input name="track" type="checkbox" value="1" <?php checked(!isset($c['track'])||$c['track']); ?>> Add the consent-gated frontend tracker automatically</label><p class="description">Do not install a second manual snippet. Tracking remains inactive until your consent manager grants analytics consent.</p><p><label><input name="track_logged_in" type="checkbox" value="1" <?php checked(!empty($c['track_logged_in'])); ?>> Include logged-in users in frontend analytics</label></p></td></tr>
        </table><?php submit_button('Save settings'); ?></form>
        <hr><h2>Connection status</h2><p><?php echo esc_html(($last['message'] ?? 'No report sent yet.').(!empty($last['at'])?' — '.gmdate('Y-m-d H:i:s',(int)$last['at']).' UTC':'')); ?></p>
        <?php if(self::ready()): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="clientwatch_send"><?php wp_nonce_field('clientwatch_send'); ?><?php submit_button('Send report & refresh checks','secondary'); ?></form><?php endif; ?>
        <p>Reports are scheduled every five minutes. WP-Cron normally needs page visits; configure your hosting scheduler for reliable reporting on quiet sites. PHP fatal errors are queued only after this plugin has loaded and when the WordPress database is still available.</p>
        <h2>Consent manager integration</h2><p>When analytics consent is granted (including previously stored consent), run:</p><pre><code>window.ClientWatchConsent = true;
window.ClientWatch?.consent(true);</code></pre><p>When it is withdrawn, run:</p><pre><code>window.ClientWatchConsent = false;
window.ClientWatch?.consent(false);</code></pre><p>The tracker honours Do Not Track and Global Privacy Control. If you use a Content Security Policy, allow the dashboard's origin in <code>connect-src</code>. No form values, cookies or user accounts are intentionally collected. Review error-message privacy before enabling production monitoring.</p>
        <p><strong>Update checks are not a vulnerability scan.</strong> Premium updates appear only when the relevant updater and licence supply them to WordPress. On multisite, configure each intended site explicitly; network activation does not provision separate dashboard entries.</p></div>
        <?php
    }
    public static function enqueue(): void {
        $c=self::config();if(!self::ready()||empty($c['track'])||(is_user_logged_in()&&empty($c['track_logged_in'])))return;
        wp_enqueue_script('clientwatch-tracker',plugins_url('assets/tracker.js',__FILE__),[],self::VERSION,true);
    }
    public static function script_tag(string $tag,string $handle): string {
        if($handle!=='clientwatch-tracker')return $tag;$c=self::config();
        $attrs=' defer data-site="'.esc_attr($c['site']).'" data-key="'.esc_attr($c['public_key']).'" data-consent="required" data-endpoint="'.esc_url($c['url'].'?api=collect').'"';
        return preg_replace('/<script\b/','<script'.$attrs,$tag,1) ?? $tag;
    }
    public static function after_upgrade(mixed $upgrader,array $options): void { if(self::ready()&&!wp_next_scheduled(self::FORCE))wp_schedule_single_event(time()+20,self::FORCE); }
    public static function manual(): void {
        self::capability();check_admin_referer('clientwatch_send');
        if(!self::ready())self::go('Save all connection values first.');
        $ok=self::send(false);if(!wp_next_scheduled(self::FORCE))wp_schedule_single_event(time()+1,self::FORCE);
        self::go($ok?'Current report sent. Fresh update checks are queued for WP-Cron.':'The report could not be sent. Check the connection status below; a fresh report remains queued.');
    }
    public static function scheduled(): void { self::send(false); }
    public static function fresh(): void { self::send(true); }
    private static function update_checks(): bool {
        if(time()-(int)get_option('cw_last_forced',0)<240)return false;
        update_option('cw_last_forced',time(),false);
        require_once ABSPATH.'wp-includes/update.php';require_once ABSPATH.'wp-admin/includes/update.php';
        foreach(['update_plugins','update_themes'] as $key){$current=get_site_transient($key);if(is_object($current)){$current->last_checked=0;set_site_transient($key,$current);}}
        wp_version_check([],true);wp_update_plugins();wp_update_themes();
        return true;
    }
    private static function report(): array {
        global $wp_version;
        require_once ABSPATH.'wp-admin/includes/plugin.php';require_once ABSPATH.'wp-admin/includes/update.php';
        $pu=get_site_transient('update_plugins');$tu=get_site_transient('update_themes');$cu=get_site_transient('update_core');
        $plugins=[];foreach(get_plugins() as $file=>$p)$plugins[]=['name'=>wp_strip_all_tags($p['Name'] ?? $file),'version'=>$p['Version'] ?? '', 'new_version'=>$pu->response[$file]->new_version ?? '', 'active'=>is_plugin_active($file)||is_plugin_active_for_network($file)];
        $themes=[];$current=get_stylesheet();foreach(wp_get_themes() as $slug=>$theme)$themes[]=['name'=>wp_strip_all_tags($theme->get('Name')),'version'=>$theme->get('Version'),'new_version'=>$tu->response[$slug]['new_version'] ?? '', 'active'=>$slug===$current||$slug===get_template()];
        $core='';foreach((array)($cu->updates ?? []) as $update)if(($update->response ?? '')==='upgrade'){$core=(string)$update->version;break;}
        return ['kind'=>'wordpress','connector'=>self::VERSION,'runtime'=>'PHP '.PHP_VERSION,'wordpress'=>['version'=>$wp_version,'php'=>PHP_VERSION,'core_update'=>$core,'plugins'=>$plugins,'themes'=>$themes,'debug'=>defined('WP_DEBUG')&&WP_DEBUG,'cron_disabled'=>defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON,'multisite'=>is_multisite(),'admin_url'=>admin_url('update-core.php'),'checks'=>['core'=>(int)($cu->last_checked ?? 0),'plugins'=>(int)($pu->last_checked ?? 0),'themes'=>(int)($tu->last_checked ?? 0)]]];
    }
    private static function scrub(string $text): string {
        $text=substr(wp_strip_all_tags($text),0,1000);
        $text=preg_replace('/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i','[email]',$text) ?? '';
        $text=preg_replace('/\b(password|passwd|token|api[_-]?key|secret|authorization|cookie)\s*[:=]\s*[^\s,;]+/i','$1=[redacted]',$text) ?? '';
        return preg_replace('~(https?://[^\s?#]+)[?#][^\s]*~i','$1',$text) ?? '';
    }
    public static function shutdown(): void {
        if(self::$sending||!self::ready())return;$e=error_get_last();
        if(!$e||!in_array($e['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR,E_RECOVERABLE_ERROR],true))return;
        try{
            global $wpdb;if(!$wpdb)return;
            $count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s",$wpdb->esc_like('cw_evt_').'%'));
            if($count>=100)return;
            $id=bin2hex(random_bytes(12));
            add_option('cw_evt_'.$id,['id'=>$id,'severity'=>'critical','message'=>self::scrub($e['message']),'file'=>basename($e['file']),'line'=>(int)$e['line'],'path'=>(string)(wp_parse_url($_SERVER['REQUEST_URI'] ?? '/',PHP_URL_PATH) ?: '/')],'',false);
        }catch(Throwable $ignore){}
    }
    public static function send(bool $fresh=false): bool {
        if(!self::ready()||self::$sending||get_transient('cw_report_lock'))return false;
        self::$sending=true;set_transient('cw_report_lock',1,180);
        try{
            global $wpdb;$c=self::config();$didFresh=$fresh?self::update_checks():false;
            $queued=$wpdb->get_results($wpdb->prepare("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_id ASC LIMIT 30",$wpdb->esc_like('cw_evt_').'%'),ARRAY_A) ?: [];
            $errors=[];foreach($queued as $row){$v=maybe_unserialize($row['option_value']);if(is_array($v))$errors[]=$v;}
            $body=wp_json_encode(['report'=>self::report(),'errors'=>$errors,'fresh'=>$didFresh]);
            if(!is_string($body))throw new RuntimeException('Cannot encode the backend report.');
            $ts=(string)time();$nonce=bin2hex(random_bytes(16));$sig=hash_hmac('sha256',$ts."\n".$nonce."\n".$body,$c['secret']);
            $args=['timeout'=>10,'redirection'=>0,'sslverify'=>true,'headers'=>['Content-Type'=>'application/json','X-CW-Site'=>$c['site'],'X-CW-Timestamp'=>$ts,'X-CW-Nonce'=>$nonce,'X-CW-Signature'=>$sig],'body'=>$body,'data_format'=>'body'];
            $response=self::local()?wp_remote_post($c['url'].'?api=report',$args):wp_safe_remote_post($c['url'].'?api=report',$args);
            if(is_wp_error($response))throw new RuntimeException($response->get_error_message());
            $code=(int)wp_remote_retrieve_response_code($response);$json=json_decode(wp_remote_retrieve_body($response),true);
            if($code!==200||empty($json['ok']))throw new RuntimeException('Dashboard rejected the report (HTTP '.$code.'). '.sanitize_text_field($json['error'] ?? 'Check URL and credentials.'));
            foreach($queued as $row)delete_option($row['option_name']);
            update_option('cw_last_status',['at'=>time(),'message'=>'Report accepted by dashboard'.($didFresh?' after fresh update checks.':'.')],false);
            if(!empty($json['refresh_requested'])&&!wp_next_scheduled(self::FORCE))wp_schedule_single_event(time()+5,self::FORCE);
            return true;
        }catch(Throwable $e){update_option('cw_last_status',['at'=>time(),'message'=>'Report failed: '.self::scrub($e->getMessage())],false);return false;}
        finally{delete_transient('cw_report_lock');self::$sending=false;}
    }
}
ClientWatch_Connector::init();
register_activation_hook(__FILE__,[ClientWatch_Connector::class,'activate']);
register_deactivation_hook(__FILE__,[ClientWatch_Connector::class,'deactivate']);
