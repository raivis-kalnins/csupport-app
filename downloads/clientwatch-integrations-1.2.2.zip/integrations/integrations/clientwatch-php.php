<?php
declare(strict_types=1);
/**
 * ClientWatch PHP integration 1.2.2.
 *
 * Server-side only. Configure these environment variables:
 *   CLIENTWATCH_URL=https://monitor.example.com/index.php
 *   CLIENTWATCH_SITE_ID=0123456789abcdef
 *   CLIENTWATCH_SECRET=<64 hex chars>
 *
 * Include this file as early as practical and call:
 *   ClientWatchReporter::registerHandlers();
 *
 * This does NOT require WordPress or wp-config.php and does not expose the
 * backend secret to the browser. PHP's normal logging/display configuration is
 * left in control; ClientWatch receives a redacted copy of reportable errors.
 */
final class ClientWatchReporter {
    private static string $reserve='';
    private static bool $registered=false;
    private static bool $sendingError=false;
    private static mixed $previousErrorHandler=null;
    private static mixed $previousExceptionHandler=null;

    private static function config(): array {
        $url=rtrim((string)getenv('CLIENTWATCH_URL'),'/');
        $id=(string)getenv('CLIENTWATCH_SITE_ID');
        $secret=(string)getenv('CLIENTWATCH_SECRET');
        if (!filter_var($url,FILTER_VALIDATE_URL)||!str_ends_with((string)parse_url($url,PHP_URL_PATH),'/index.php')||parse_url($url,PHP_URL_QUERY)||parse_url($url,PHP_URL_FRAGMENT)||parse_url($url,PHP_URL_USER)) throw new RuntimeException('Set a valid CLIENTWATCH_URL ending with /index.php.');
        if (!str_starts_with($url,'https://')&&!(getenv('CLIENTWATCH_ALLOW_HTTP')==='1'&&str_starts_with($url,'http://'))) throw new RuntimeException('Use HTTPS. CLIENTWATCH_ALLOW_HTTP=1 is for local development only.');
        if (!preg_match('/^[a-f0-9]{16}$/',$id)||!preg_match('/^[a-f0-9]{64}$/',$secret)) throw new RuntimeException('Set CLIENTWATCH_SITE_ID and CLIENTWATCH_SECRET on the server.');
        return [$url,$id,$secret];
    }
    private static function redact(string $s,int $max=4000): string {
        $s=substr($s,0,$max);
        $s=preg_replace('/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i','[email]',$s) ?? '';
        $s=preg_replace('/\b(password|passwd|token|api[_-]?key|secret|authorization|cookie)\s*[:=]\s*[^\s,;]+/i','$1=[redacted]',$s) ?? '';
        $s=preg_replace('~(https?://[^\s?#]+)[?#][^\s]*~i','$1',$s) ?? '';
        return preg_replace('/\b[a-f0-9]{32,}\b/i','[identifier]',$s) ?? '';
    }
    private static function path(): string {
        $path=(string)(parse_url($_SERVER['REQUEST_URI'] ?? '/',PHP_URL_PATH) ?: '/');
        return substr($path,0,300);
    }
    private static function errorTypeName(int $type): string {
        return match($type){
            E_ERROR=>'E_ERROR',E_WARNING=>'E_WARNING',E_PARSE=>'E_PARSE',E_NOTICE=>'E_NOTICE',E_CORE_ERROR=>'E_CORE_ERROR',E_CORE_WARNING=>'E_CORE_WARNING',E_COMPILE_ERROR=>'E_COMPILE_ERROR',E_COMPILE_WARNING=>'E_COMPILE_WARNING',E_USER_ERROR=>'E_USER_ERROR',E_USER_WARNING=>'E_USER_WARNING',E_USER_NOTICE=>'E_USER_NOTICE',E_STRICT=>'E_STRICT',E_RECOVERABLE_ERROR=>'E_RECOVERABLE_ERROR',E_DEPRECATED=>'E_DEPRECATED',E_USER_DEPRECATED=>'E_USER_DEPRECATED',default=>'PHP_ERROR_'.$type
        };
    }
    private static function severity(int $type): string {
        return in_array($type,[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR,E_RECOVERABLE_ERROR],true)?'critical':(in_array($type,[E_WARNING,E_CORE_WARNING,E_COMPILE_WARNING,E_USER_WARNING],true)?'warning':'warning');
    }
    public static function send(array $payload): bool {
        try {
            [$url,$id,$secret]=self::config();
            $body=json_encode($payload,JSON_THROW_ON_ERROR|JSON_INVALID_UTF8_SUBSTITUTE);
            $time=(string)time();$nonce=bin2hex(random_bytes(16));$signature=hash_hmac('sha256',$time."\n".$nonce."\n".$body,$secret);
            $headers=['Content-Type: application/json','X-CW-Site: '.$id,'X-CW-Timestamp: '.$time,'X-CW-Nonce: '.$nonce,'X-CW-Signature: '.$signature];
            if (function_exists('curl_init')) {
                $ch=curl_init($url.'?api=report');
                curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_PROXY=>'',CURLOPT_CONNECTTIMEOUT=>2,CURLOPT_TIMEOUT=>3,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
                $response=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
            } else {
                $context=stream_context_create(['http'=>['method'=>'POST','header'=>implode("\r\n",$headers),'content'=>$body,'timeout'=>3,'ignore_errors'=>true,'follow_location'=>0],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
                $response=@file_get_contents($url.'?api=report',false,$context);$code=0;
                foreach($http_response_header ?? [] as $line)if(preg_match('~^HTTP/\S+\s+(\d{3})~',$line,$m))$code=(int)$m[1];
            }
            return $code===200&&is_string($response)&&!empty(json_decode($response,true)['ok']);
        } catch(Throwable $e) {
            error_log('ClientWatch reporter could not deliver a report. Check its server-side configuration and network.');
            return false;
        }
    }
    public static function heartbeat(): bool {
        $ext=[];foreach(['curl','openssl','mbstring','intl','imagick','gd','zip','mysqli','pdo','opcache'] as $name)$ext[$name]=extension_loaded($name);
        $free=@disk_free_space(__DIR__);$total=@disk_total_space(__DIR__);
        return self::send(['report'=>['kind'=>'php','connector'=>'1.2.2','runtime'=>'PHP '.PHP_VERSION,'environment'=>['platform'=>PHP_OS_FAMILY,'architecture'=>PHP_INT_SIZE===8?'64-bit':'32-bit','sapi'=>PHP_SAPI,'server'=>(string)($_SERVER['SERVER_SOFTWARE'] ?? ''),'memory_limit'=>(string)ini_get('memory_limit'),'upload_max'=>(string)ini_get('upload_max_filesize'),'post_max'=>(string)ini_get('post_max_size'),'max_execution_time'=>(string)ini_get('max_execution_time'),'disk_free_mb'=>is_numeric($free)?(int)round($free/1048576):0,'disk_total_mb'=>is_numeric($total)?(int)round($total/1048576):0,'process_memory_mb'=>(int)round(memory_get_usage(true)/1048576),'extensions'=>$ext]]]);
    }
    public static function error(Throwable|string $error,string $severity='error',string $type='ApplicationError'): bool {
        $stack=$error instanceof Throwable?$error->getTraceAsString():'';
        return self::send(['errors'=>[['id'=>bin2hex(random_bytes(12)),'message'=>self::redact($error instanceof Throwable?$error->getMessage():$error,1000),'type'=>self::redact($error instanceof Throwable?get_class($error):$type,120),'stack'=>self::redact($stack,4000),'severity'=>$severity,'file'=>$error instanceof Throwable?basename($error->getFile()):'','line'=>$error instanceof Throwable?$error->getLine():0,'path'=>self::path()]]]);
    }
    private static function reportPhpError(int $type,string $message,string $file,int $line): void {
        if(self::$sendingError)return;
        self::$sendingError=true;
        try{self::send(['errors'=>[['id'=>bin2hex(random_bytes(12)),'message'=>self::redact($message,1000),'type'=>self::errorTypeName($type),'stack'=>'','severity'=>self::severity($type),'file'=>basename($file),'line'=>$line,'path'=>self::path()]]]);}catch(Throwable $ignore){}
        finally{self::$sendingError=false;}
    }
    public static function registerHandlers(): void {
        if(self::$registered)return;
        self::$registered=true;self::$reserve=str_repeat('x',65536);
        self::$previousErrorHandler=set_error_handler(static function(int $type,string $message,string $file,int $line): bool {
            if((error_reporting() & $type)!==0)self::reportPhpError($type,$message,$file,$line);
            if(is_callable(self::$previousErrorHandler))return (bool)call_user_func(self::$previousErrorHandler,$type,$message,$file,$line);
            return false; // keep PHP's normal error handling/logging
        });
        self::$previousExceptionHandler=set_exception_handler(static function(Throwable $e): void {
            if(!self::$sendingError){self::$sendingError=true;try{self::error($e,'critical',get_class($e));}finally{self::$sendingError=false;}}
            if(is_callable(self::$previousExceptionHandler)){call_user_func(self::$previousExceptionHandler,$e);return;}
            error_log(sprintf('Uncaught %s: %s in %s:%d',get_class($e),$e->getMessage(),$e->getFile(),$e->getLine()));
            if(PHP_SAPI!=='cli'&&!headers_sent())http_response_code(500);
        });
        register_shutdown_function(static function(): void {
            self::$reserve='';$e=error_get_last();
            if(!$e||!in_array($e['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR,E_RECOVERABLE_ERROR],true))return;
            self::reportPhpError((int)$e['type'],(string)$e['message'],(string)$e['file'],(int)$e['line']);
        });
    }
    /** Backwards-compatible alias from 1.2.1. */
    public static function registerFatalHandler(): void { self::registerHandlers(); }
}
if(PHP_SAPI==='cli'&&realpath($_SERVER['SCRIPT_FILENAME'] ?? '')===__FILE__){
    if(($argv[1] ?? '')!=='--heartbeat'){fwrite(STDERR,"Usage: php clientwatch-php.php --heartbeat\n");exit(2);}
    $ok=ClientWatchReporter::heartbeat();echo $ok?"Report accepted.\n":"Report failed.\n";exit($ok?0:1);
}
