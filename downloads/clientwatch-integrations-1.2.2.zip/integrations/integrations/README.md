# ClientWatch 1.2.2 — PHP and Node.js backend integrations

The public browser tracker can report JavaScript/browser errors. These optional
server-side helpers add PHP/Node runtime health and backend error reporting.
They do not require WordPress or `wp-config.php`.

Never expose the private backend secret in browser JavaScript, HTML, URLs,
`NEXT_PUBLIC_*`, `VITE_*`, or other client-side variables.

Set these **server-side** values:

```text
CLIENTWATCH_URL=https://YOUR-DASHBOARD/index.php
CLIENTWATCH_SITE_ID=YOUR_16_CHARACTER_SITE_ID
CLIENTWATCH_SECRET=YOUR_64_CHARACTER_PRIVATE_BACKEND_SECRET
```

Use the exact values shown in the site's **Connect website** tab.

## Plain PHP

Keep `clientwatch-php.php` outside the public document root if practical, include
it early in the application's bootstrap, then register the handlers:

```php
require '/home/YOUR_ACCOUNT/private/clientwatch-php.php';
ClientWatchReporter::registerHandlers();
```

This can report:

- PHP warnings and user warnings
- PHP notices/deprecations that are enabled by the site's `error_reporting()`
- uncaught exceptions
- fatal/parse/core/compile errors detected at shutdown after the helper loaded
- error type, message, filename, line, page path and stack trace when available

ClientWatch does **not** change `display_errors`, `log_errors`, or the site's
`error_reporting()` level. Suppressed errors remain suppressed. Existing error
handlers are called after ClientWatch's reporter when possible.

You can also report a caught application exception explicitly:

```php
try {
    // application code
} catch (Throwable $exception) {
    ClientWatchReporter::error($exception, 'error');
    throw $exception;
}
```

Optional heartbeat cron:

```cron
*/5 * * * * php /home/YOUR_ACCOUNT/private/clientwatch-php.php --heartbeat
```

Make sure cron receives the same environment variables as the website.

## Node.js

Use Node.js 20+ in the server process:

```js
import {createClientWatch} from './clientwatch-node.mjs';
const monitor = createClientWatch();
const stopHeartbeat = monitor.startHeartbeat();

app.use((error, request, response, next) => {
  monitor.error(error, {path: request.path}).catch(() => {});
  next(error);
});
```

Optional process-level handlers are available:

```js
const unregister = monitor.registerProcessHandlers();
```

By default an uncaught exception is reported and the process exits with status 1;
your process manager should still be configured to restart the application and
retain its own logs.

## Browser JavaScript errors

The normal ClientWatch frontend tracker captures `window.error`, failed frontend
resources and unhandled Promise rejections. It sends the message, error type,
filename, line, page path and a redacted stack trace when the browser provides
one. Only the public tracking key is used in browser code.

## Privacy and limitations

Error messages and stack traces can contain personal or confidential data. The
helpers apply basic redaction for emails, secrets/tokens, long identifiers and
URL query strings, but pattern-based redaction cannot guarantee removal of every
sensitive value. Review your application's error messages and your retention /
privacy requirements before enabling production monitoring.

ClientWatch is an additional error inbox, not a replacement for the hosting,
PHP-FPM, application, web-server or process-manager logs. Errors that happen
before the helper loads, during a hard process kill, or while the network is
unavailable may not reach ClientWatch.
