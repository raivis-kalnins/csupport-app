<?php
if(!defined('WP_UNINSTALL_PLUGIN'))exit;
// Remove this site's credentials and buffered reports. Existing dashboard history is retained there.
wp_clear_scheduled_hook('clientwatch_send_report');wp_clear_scheduled_hook('clientwatch_fresh_report');
foreach(['clientwatch_connector','cw_last_status','cw_last_forced'] as $key)delete_option($key);
delete_transient('cw_report_lock');delete_transient('cw_admin_notice');
global $wpdb;
$keys=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",$wpdb->esc_like('cw_evt_').'%'));
foreach($keys as $key)delete_option($key);
